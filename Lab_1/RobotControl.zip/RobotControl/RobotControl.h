#ifndef RobotControl_h
#define RobotControl_h

#include <Arduino.h>

// Define pin numbers for left motor
#define LPWM 6  // PWM control for left motor speed
#define LDIR 11  // Direction control for left motor

// Define pin numbers for right motor
#define RPWM 5  // PWM control for right motor speed
#define RDIR 9  // Direction control for right motor

class RobotControl {
  public:
    RobotControl();

    void begin();

    void speed_run(int speedDC_left, int speedDC_right);

  private:
    // Add any private variables or helper functions here
};

#endif

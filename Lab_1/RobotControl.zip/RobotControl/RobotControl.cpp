#include "RobotControl.h"

RobotControl::RobotControl() {
  // Constructor
}

void RobotControl::begin() {
  // Initialize motor control pins
  pinMode(LPWM, OUTPUT);
  pinMode(LDIR, OUTPUT);
  pinMode(RPWM, OUTPUT);
  pinMode(RDIR, OUTPUT);
  digitalWrite(RDIR, LOW);
  digitalWrite(LDIR, LOW);
}

void RobotControl::speed_run(int speedDC_left, int speedDC_right) {
  // Control left motor
  if (speedDC_left < 0) {
    analogWrite(LPWM, 255 + speedDC_left);
    digitalWrite(LDIR, HIGH);
  } else {
    analogWrite(LPWM, speedDC_left);
    digitalWrite(LDIR, LOW);
  }

  // Control right motor
  if (speedDC_right < 0) {
    analogWrite(RPWM, 255 + speedDC_right);
    digitalWrite(RDIR, HIGH);
  } else {
    analogWrite(RPWM, speedDC_right);
    digitalWrite(RDIR, LOW);
  }
}
